

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.interfaces.WriteToUsDao;
import com.techm.implementations.WriteToUsImpl;


public class AnswerQueryServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private WriteToUsDao writeToUsDao;


	public void init(ServletConfig config) throws ServletException 
	{
		writeToUsDao=new WriteToUsImpl();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		HttpSession session=request.getSession();
		String userName=request.getParameter("userName");
		String answer=request.getParameter("answer");
		writeToUsDao.submitAnswer(userName, answer);
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<center><h2>Query Answered!</h2>");
	
		RequestDispatcher rd=request.getRequestDispatcher("/queries.jsp");
		rd.include(request,response );
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
