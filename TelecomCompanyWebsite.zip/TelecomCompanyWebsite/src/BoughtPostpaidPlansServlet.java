

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.implementations.BillImpl;
import com.techm.interfaces.BillDao;
import com.techm.classes.Admin;
import com.techm.classes.Bill;
import com.techm.classes.Customer;
import com.techm.classes.Plan;


/**
 * Servlet implementation class BoughtPostpaidPlansServlet
 */
public class BoughtPostpaidPlansServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BillDao billDao;
    /**
     * @see HttpServlet#HttpServlet()
     */
	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("BoughtPostpaidPlansServlet Servlet Init invoked!");
		billDao=new BillImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String b=request.getParameter("postpaidsave");
		
		Customer c=new Customer();
		Plan p=new Plan();
		boolean isadded=billDao.addPlans(c, p);
		
		if(isadded==true)
		{
			RequestDispatcher rd=request.getRequestDispatcher("paymentsuccessfull.html");
			rd.forward(request, response);
		}
		else
		{
			System.out.println("oops..!!!     something went wrong!!!");
			RequestDispatcher rd=request.getRequestDispatcher("viewpostpaidplans.jsp");
			rd.include(request, response);
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
