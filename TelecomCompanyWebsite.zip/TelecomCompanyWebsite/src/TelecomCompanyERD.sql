
/* Drop Triggers */

DROP TRIGGER TRI_plan_planid;



/* Drop Tables */

DROP TABLE bill CASCADE CONSTRAINTS;
DROP TABLE plan CASCADE CONSTRAINTS;
DROP TABLE customer CASCADE CONSTRAINTS;
DROP TABLE writetous CASCADE CONSTRAINTS;
DROP TABLE admin CASCADE CONSTRAINTS;
DROP TABLE store CASCADE CONSTRAINTS;



/* Drop Sequences */

DROP SEQUENCE SEQ_plan_planid;




/* Create Sequences */

CREATE SEQUENCE SEQ_plan_planid INCREMENT BY 1 START WITH 1;



/* Create Tables */

CREATE TABLE admin
(
	username varchar2(20) NOT NULL UNIQUE,
	password varchar2(20) NOT NULL,
	PRIMARY KEY (username)
);


CREATE TABLE bill
(
	username varchar2(20) NOT NULL UNIQUE,
	planid number(10) NOT NULL UNIQUE,
	status number(10),
	mobileno number(20) NOT NULL UNIQUE,
	amount number(10),
	PRIMARY KEY (mobileno)
);


CREATE TABLE customer
(
	username varchar2(20) NOT NULL UNIQUE,
	password varchar2(20) NOT NULL,
	city varchar2(20) NOT NULL,
	useremail varchar2(30) UNIQUE,
	cellno varchar2(20) NOT NULL UNIQUE,
	PRIMARY KEY (username)
);


CREATE TABLE plan
(
	planid number(10) NOT NULL UNIQUE,
	plantype varchar2(10) NOT NULL,
	plandetails varchar2(30) NOT NULL,
	charges number(20) NOT NULL,
	validity number(10) NOT NULL,
	username varchar2(20) NOT NULL UNIQUE,
	username varchar2(20) NOT NULL UNIQUE,
	PRIMARY KEY (planid)
);


CREATE TABLE store
(
	locationid number(20) NOT NULL,
	city varchar2(20),
	addresses varchar2(50)
);


CREATE TABLE writetous
(
	query varchar2(500),
	status number(1),
	username varchar2(20) NOT NULL UNIQUE,
	usercity varchar2(20),
	useremail varchar2(30) UNIQUE,
	usercontact number(20) UNIQUE
);



/* Create Foreign Keys */

ALTER TABLE plan
	ADD FOREIGN KEY (username)
	REFERENCES admin (username)
;


ALTER TABLE writetous
	ADD FOREIGN KEY (username)
	REFERENCES admin (username)
;


ALTER TABLE plan
	ADD FOREIGN KEY (username)
	REFERENCES customer (username)
;


ALTER TABLE bill
	ADD FOREIGN KEY (username)
	REFERENCES customer (username)
;


ALTER TABLE bill
	ADD FOREIGN KEY (planid)
	REFERENCES plan (planid)
;


ALTER TABLE customer
	ADD FOREIGN KEY (useremail)
	REFERENCES writetous (useremail)
;



/* Create Triggers */

CREATE OR REPLACE TRIGGER TRI_plan_planid BEFORE INSERT ON plan
FOR EACH ROW
BEGIN
	SELECT SEQ_plan_planid.nextval
	INTO :new.planid
	FROM dual;
END;

/




