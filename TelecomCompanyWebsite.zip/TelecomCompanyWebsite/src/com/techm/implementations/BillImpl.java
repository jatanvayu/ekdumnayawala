package com.techm.implementations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.mysql.jdbc.Connection;
import com.techm.classes.Bill;
import com.techm.classes.Customer;
import com.techm.classes.Plan;
import com.techm.connection.jdbcConnection;
import com.techm.interfaces.PlanDao;
import com.techm.implementations.PlanImpl;
import com.techm.interfaces.BillDao;
import com.techm.interfaces.PlanDao;



public class BillImpl implements BillDao
{

	jdbcConnection jcon = new jdbcConnection();
	Connection con;
	

	public boolean addPlans(Customer customer,Plan plan) 
	{
		/*PlanDao planDao=new PlanImpl();*/
		Bill b=new Bill();
		boolean isadded=false;
		
			String SQL="insert into bill values(?,?,?,?,?)";

			jcon.getConnection();
			try 
			{	
				System.out.println(plan.getPlanType()+"value");

				Date date=new Date();
				String d=date.toString();
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, customer.getUsername());
				ps.setInt(2, plan.getPlanId());
				ps.setInt(3, 0);
				ps.setLong(4, b.getMobileNo());
				ps.setDouble(5, plan.getCharges());


				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					isadded=true;
					System.out.println("Plan Added!");
				}
				else
				{
					System.out.println("Plan not Added!");
				}
			} 
			catch (SQLException e) 
			{

				e.printStackTrace();
			}
			finally
			{
				jcon.closeConnection();
			}
		
			return isadded;
	}



		public boolean removePlans() 
		{
			/*PlanDao planDao=new PlanImpl();*/
			Bill b=new Bill();
			boolean isremoved=false;
				String SQL="delete from bill where mobileNo=?";

				jcon.getConnection();
				try 
				{	
					/*System.out.println(s);*/
					/*int c=Integer.parseInt(s);
					System.out.println(planDao.getPlan(c).getPlanType()+"value");*/

					
					PreparedStatement ps=con.prepareStatement(SQL);
					ps.clearParameters();
					ps.setLong(1, b.getMobileNo());
					/*ps.setInt(2, planDao.getPlan(c).getPlanId());
					ps.setInt(3, 0);
					ps.setString(4, "valid");
					ps.setDouble(5, planDao.getPlan(c).getCharges())*/;


					int cnt=ps.executeUpdate();
					if(cnt==1)
					{
						isremoved=true;
						System.out.println("Bill Paid!");
					}
					else
					{
						System.out.println("Bill Not Paid!");
					}
				} 
				catch (SQLException e) 
				{

					e.printStackTrace();
				}
				finally
				{
					jcon.closeConnection();
				}
			
			return isremoved;
		}
		
		
		
		/*public ArrayList<Bill> getAllUnpaidPlans(Customer customer,Plan plan) {
			String SQL="select * from bill";
			ArrayList<Bill> UnpaidPlansList=new ArrayList<Bill>();
			Bill bill=null;
			jcon.getConnection();
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ResultSet rs=ps.executeQuery();
				//Since multiple records are expected we use while
				while(rs.next())
				{
					bill=new Bill();
					bill.setUsername(rs.getString("username"));
					bill.setPlanId(rs.getInt("planid"));
					bill.setStatus(rs.getInt("status"));
					bill.setMobileNo(rs.getInt("mobileno"));
					bill.setAmount(rs.getInt("amount"));
					UnpaidPlansList.add(bill);
				}
			} 
			catch (SQLException e) 
			{

				e.printStackTrace();
			}
			finally
			{
				jcon.closeConnection();
			}
			return UnpaidPlansList;

		}*/
}
