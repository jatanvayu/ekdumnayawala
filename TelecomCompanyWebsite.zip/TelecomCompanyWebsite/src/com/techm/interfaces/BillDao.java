package com.techm.interfaces;

import java.util.ArrayList;

import com.techm.classes.Customer;
import com.techm.classes.Bill;
import com.techm.classes.Plan;
public interface BillDao {
	
	public boolean addPlans(Customer customer,Plan plan);
	public boolean removePlans();
}
