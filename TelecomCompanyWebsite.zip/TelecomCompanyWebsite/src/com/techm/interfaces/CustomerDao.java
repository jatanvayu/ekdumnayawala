package com.techm.interfaces;

import com.techm.classes.Customer;

public interface CustomerDao {
	
	public boolean addCustomer(Customer customer);
	public boolean validateCustomer(Customer customer);
}
