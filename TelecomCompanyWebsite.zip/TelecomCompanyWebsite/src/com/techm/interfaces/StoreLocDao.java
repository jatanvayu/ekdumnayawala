package com.techm.interfaces;

public interface StoreLocDao {
	
	public String getAddresses(String city);
}
